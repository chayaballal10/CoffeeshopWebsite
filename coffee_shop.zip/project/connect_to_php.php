<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    $conn = new mysqli('localhost', 'root', '', 'coffeeshop');
    if ($conn->connect_error) {
        die('Connection Failed:' . $conn->connect_error);
    } else {
        $stmt = $conn->prepare("INSERT INTO registration (name, email, phone, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $phone, $message);
        if ($stmt->execute()) {
            echo "Registration successful";
        } else {
            echo "Error: " . $conn->error;
        }
        $stmt->close();
        $conn->close();
    }
} else {
    echo "error";
}
?>
