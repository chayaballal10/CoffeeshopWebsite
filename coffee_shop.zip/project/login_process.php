

 <?php
// Start session
session_start();

// Check if form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection
    // Establish a connection to the database
    $conn = mysqli_connect("localhost", "root", "", "coffeeshop");

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get username and password from form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Perform SQL query to check if user exists
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    // Check if query was successful and user exists
    if ($result && mysqli_num_rows($result) == 1) {
        // User authenticated, set session variable and redirect to home page
        $_SESSION["username"] = $username;
        header("Location: index.html");
        exit;
    } else {
        // User not found or incorrect credentials, redirect back to login page with error message
        $_SESSION["login_error"] = "Invalid username or password";
        header("Location: index.html");
        exit;
    }
} else {
    // Redirect back to login page if accessed directly
    header("Location: index.html");
    exit;
}


?>
