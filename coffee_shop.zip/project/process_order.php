<?php
// Establish a connection to the database
$conn = mysqli_connect("localhost", "root", "", "coffeeshop");

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Generate a unique customer ID
$cid = uniqid();

// Escape user inputs for security
$cname = mysqli_real_escape_string($conn, $_POST['cname']);
$address = mysqli_real_escape_string($conn, $_POST['address']);
$phone = mysqli_real_escape_string($conn, $_POST['phone']);
$payment = mysqli_real_escape_string($conn, $_POST['payment']);

// Attempt to insert customer details into the 'customer' table
$sql = "INSERT INTO `customer` (cid, cname, address, phone) VALUES ('$cid', '$cname', '$address', '$phone')";
if (mysqli_query($conn, $sql)) {
    echo "Customer records added successfully.";
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

// Attempt to insert order details into the 'order' table
$sql = "INSERT INTO `order` (cid, cname, payment) VALUES ('$cid', '$cname', '$payment')";
if (mysqli_query($conn, $sql)) {
    echo "Order records added successfully.";
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>
