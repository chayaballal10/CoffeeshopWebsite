<?php
// Start session
session_start();

// Check if form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = mysqli_connect("localhost", "root", "", "coffeeshop");

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    

    // Get form data
    $name = $_POST["name"];
    $address = $_POST["address"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $password=$_POST["password"];
    // Generate CID (you can use any unique identifier method)
    $cid = uniqid();

    // Perform SQL query to insert new customer
    $sql = "INSERT INTO users (cid, username, address, phone, email,password) VALUES ('$cid', '$name', '$address', '$phone', '$email','$password')";
    if (mysqli_query($conn, $sql)) {
        // Registration successful, set session variable and redirect to home page
        $_SESSION["cid"] = $cid;
        header("Location: index.html");
        exit;
    } else {
        // Registration failed, redirect back to registration page with error message
        $_SESSION["register_error"] = "Registration failed. Please try again.";
        header("Location: register.php");
        exit;
    }
} else {
    // Redirect back to registration page if accessed directly
    header("Location: index.html");
    exit;
}
?>
